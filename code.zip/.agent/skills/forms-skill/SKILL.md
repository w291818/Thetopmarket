---
name: forms-skill
description: Shadcn Form + React Hook Form + Zod 表单开发规范，包含类型推导、布局、验证等最佳实践
---

# Forms Skill

Shadcn Form + React Hook Form + Zod 表单开发。

## Guidelines

- 类型必须用 `z.infer` 推导，禁止手动定义
- 所有字段必须有默认值
- 必须用 Shadcn 组件，禁止原生 input
- 同行 FormField 必须等宽

---

## Example

```tsx
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { logger } from "@lark-apaas/client-toolkit-lite";

const studentSchema = z.object({
  name: z.string().min(1, "姓名不能为空"),
  age: z.coerce.number().min(0, "年龄不能为负数"),
  grade: z.string().min(1, "请选择年级"),
});

type StudentFormData = z.infer<typeof studentSchema>;

export function StudentForm() {
  const form = useForm<StudentFormData>({
    resolver: zodResolver(studentSchema),
    defaultValues: { name: "", age: 0, grade: "" },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit((data) => logger.info(data))} className="space-y-6">
        <div className="flex flex-wrap gap-4">
          <FormField control={form.control} name="name" render={({ field }) => (
            <FormItem className="flex-1">
              <FormLabel>姓名 <span className="text-destructive">*</span></FormLabel>
              <FormControl><Input placeholder="请输入姓名" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="age" render={({ field }) => (
            <FormItem className="flex-1">
              <FormLabel>年龄 <span className="text-destructive">*</span></FormLabel>
              <FormControl><Input type="number" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
        </div>
        <FormField control={form.control} name="grade" render={({ field }) => (
          <FormItem>
            <FormLabel>年级 <span className="text-destructive">*</span></FormLabel>
            <Select onValueChange={field.onChange} defaultValue={field.value}>
              <FormControl><SelectTrigger><SelectValue placeholder="请选择" /></SelectTrigger></FormControl>
              <SelectContent>
                <SelectItem value="grade1">一年级</SelectItem>
                <SelectItem value="grade2">二年级</SelectItem>
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )} />
        <Button type="submit">提交</Button>
      </form>
    </Form>
  );
}
```

---

## Patterns

```tsx
// Schema → Type → Form
const schema = z.object({ field: z.string().min(1) });
type FormData = z.infer<typeof schema>;
const form = useForm<FormData>({ resolver: zodResolver(schema), defaultValues: { field: "" } });

// 同行等宽
<div className="flex flex-wrap gap-4">
  <FormField className="flex-1" />
  <FormField className="flex-1" />
</div>

// 必填标记
<FormLabel>字段 <span className="text-destructive">*</span></FormLabel>

// 调试
logger.info("errors:", form.formState.errors);
```
