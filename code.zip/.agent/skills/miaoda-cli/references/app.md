---
name: miaoda-app
description: 当需要查看 / 修改当前 modern 应用的元数据（名称、描述、状态、类型等）或初始化应用代码骨架（拉 template、装依赖、写 .spark/meta.json）时使用。本 skill 操作的是应用对象本身与本地代码骨架，不涉及业务代码、数据库、文件、发布流。
---

# miaoda app

modern 应用元数据与本地骨架的 CLI 操作集:

- `app get`：查看当前应用元数据
- `app update`：修改应用名称 / 描述
- `app init`：初始化应用代码骨架（仅 modern 模式可用）

> 完整 flag 见 `miaoda app <command> --help`。

## 何时使用

✅ **匹配场景**

- 用户要求查看当前应用名 / 描述 / 状态 / 类型
- 用户要求重命名应用、改应用描述
- 新建应用第一次进沙箱、需要把 template 渲染下来

❌ **不匹配场景**

- 创建 / 删除应用 → 走平台 UI（CLI 不支持）
- 切换当前应用上下文 → 设置 `MIAODA_APP_ID` 环境变量；CLI 不维护本地"当前应用"状态
- 改业务代码、跑数据库、发布 → 用对应域的 skill

## 应用上下文

`app` 域所有命令隐式作用在沙箱注入的 `MIAODA_APP_ID` 上，无需显式传 `--app-id`。

## app init

modern 模式专属。把指定 template 渲染到当前目录，写 `.spark/meta.json`，默认会跑 `npm install`。

- `--template <stack>`：技术栈短名，取值见 `--help`
- `--skip-install`：跳过依赖安装
- `--conf '{"version": "..."}'`：指定 template 版本（默认 latest）

**幂等**：`.spark/meta.json` 已存在则直接退出，不会重复渲染或重装依赖；返回 `data.initialized=false, reason=already_initialized`。

### .spark/meta.json 形态

init 成功后落盘的字段（其它字段会被 deploy 等流程按需追加 / 更新）：

| 字段 | 含义 |
|---|---|
| `appId` | 沙箱注入的 `MIAODA_APP_ID` |
| `stack` | 脚手架短名，如 `vite-react` |
| `version` | template 包版本 |
| `archType` | `Fullstack` / `Frontend`，来自 template 的 `package.json.miaodaTemplate.archType` |
| `appUrl` | 最近一次 `miaoda deploy` 成功后写入的访问地址（init 阶段不写） |

需要其它信息（依赖安装来源 / 同步的 steering 版本等）请读 `app init` 的 emit 输出，不要依赖 meta.json。

## 协作约束

- `app update` 至少传 `--name` 或 `--description` 之一，缺失会以退出码 2（用法错误）失败。
- `app update` 返回结构与 `app get` 一致 —— 改完不必再调一次 `get` 确认。
- `app init` 后通常紧跟 `miaoda deploy` 把骨架推上线，让用户尽早看到 URL。
