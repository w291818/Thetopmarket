---
name: miaoda-deploy
description: 当需要把当前 modern 应用本地构建并发布到妙搭运行环境时使用。这是一个同步命令，跑完就拿到访问 URL，不需要轮询、查历史、看错误日志（modern 模式不存在这些子命令）。
---

# miaoda deploy

触发当前 modern 应用的一次发布。

```bash
miaoda deploy [--dir <path>] [--skip-build]
```

> 完整 flag 见 `miaoda deploy --help`。

## 何时使用

✅ 用户说"上线 / 发布 / 部署一下"
✅ 改完代码想看线上效果
✅ 需要应用的访问 URL

❌ 改代码 / 改配置（用代码编辑工具）
❌ 想看运行时日志或监控（modern 模式下 CLI 不提供）

## 前置要求

发布前确认这些都已经满足，缺任一项 deploy 会直接报错：

- 当前目录(或 `--dir`)已经走过 `miaoda app init`（存在 `.spark/meta.json`）
- `node_modules` 已安装、`package.json` 含 `build` script
- 工作目录在妙搭沙箱里（依赖沙箱预装的 tosutil）

## 调用方式

**默认场景** —— 直接调用,等命令返回即可:

```bash
miaoda deploy
```

**命令本身是同步的**:跑完才返回,返回时要么 `data.url` 是可用的访问地址、要么进程以非 0 退出 + stderr 错误信息。**不要**加 `&` / `nohup` / 后台 task,也**不需要**自己轮询。

**已经构建好**(比如刚跑过 `npm run build`,产物还在 `dist/` 里):

```bash
miaoda deploy --skip-build
```

**项目不在当前目录**:

```bash
miaoda deploy --dir ./my-app
```

## 输出

JSON(`--json`):

```json
{
  "data": {
    "appId": "app_xxx",
    "version": "5",
    "url": "https://...访问地址...",
    "releaseID": "...",
    "preReleaseID": "..."
  }
}
```

`data.url` 就是新版本的访问 URL,直接给用户。`releaseID` / `preReleaseID` 留作排查用,日常对话不必展示。

Pretty 模式 stderr 会按步骤打进度(`[deploy] Pre-releasing... / Building... / Uploading... / Deployed successfully`),Agent 不需要解析这些 —— 退出码 + 最终 JSON / 最后一行 stdout 就够了。

## 失败处理

`miaoda deploy` 失败时**进程退出码非 0**,stderr 会写明错误码与原因(如构建失败、上传失败、签发凭证失败等)。

- 错误信息基本能定位 —— 构建错就读 stderr 里 `npm run build` 的输出,产物上传错读 `[tosutil]` 前缀那几行。
- 改完代码重新跑 `miaoda deploy` 即可,不需要清理任何中间态。
- 同一类错误改 3 次还修不掉,**停下来告诉用户**当前错误信息和你怀疑的方向,让用户介入。

## 前置检查 —— git 工作区

跟 default 模式不同,modern 的 `miaoda deploy` 跑的是**本地工作区**,不依赖远端 HEAD。所以**不必**强制要求 commit + push。但仍建议:

- 跑之前先 `git status` 让用户对当下要发的内容有概念
- 跑之前如果用户明显是"先发布再迭代",不要画蛇添足要求他提交代码

不要把 default 模式的"必须 commit + push"那套规则套到 modern 上。
