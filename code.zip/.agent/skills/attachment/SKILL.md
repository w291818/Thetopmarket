---
name: attachment
description: "Use when user mentions attachments, uploaded files, or shared files. Handles preprocessing: listing, extracting archives, and reading files in .agent/{conversation_id}/attachments directory."
---

# Attachment Preprocessing

Preprocess user-uploaded attachments to make them accessible for subsequent workflows.

**Important**: This skill only handles attachment preprocessing (listing, extracting, reading). Subsequent processing workflows should be determined based on the extracted file contents.

## Storage Location

```text
.agent/{conversation_id}/attachments/
```

## Preprocessing Steps

### 1. List Attachments

```bash
ls -la .agent/{conversation_id}/attachments/
```

### 2. Handle Archives

For `.zip` and other archive files, preview first then extract:

```bash
# Preview contents
unzip -l .agent/{conversation_id}/attachments/archive.zip

# Extract in place
unzip -o .agent/{conversation_id}/attachments/archive.zip -d .agent/{conversation_id}/attachments/
```

### 3. Read Files

Use the Read tool to read text file contents.

## What Happens Next

After preprocessing, **determine subsequent processing based on file contents**:

- Code files → May need analysis, refactoring, or project integration
- Config files → May need to apply to project configuration
- Data files → May need data analysis or visualization
- Image files → May need to copy to project resource directories
- Document files → May need reading, comprehension, or information extraction

**This skill does not prescribe specific processing methods** — determine based on user intent and file contents.

## Notes

- All operations are confined to `.agent/{conversation_id}/attachments/` directory
- Use `offset` and `limit` parameters when reading large files
- Attachments may be cleaned up after conversation ends
