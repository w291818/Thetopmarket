# Style Presets Reference


---

## CRITICAL: Viewport Fitting (Non-Negotiable)

**Every slide MUST fit in one viewport.** Overflow → split into the next slide; never shrink fonts or compress layout. Split by meaning (each sub-slide gets its own sub-title), not by mechanical 1/3-2/3 slicing.

### Design Target: Short Viewports

**Design for the SHORTER viewport, not the taller one.** A slide that fits on a tall desktop often truncates when the viewport is short — small laptops, zoomed browsers, split-screen windows. If it fits in a constrained height, it fits everywhere.

### Content Density Limits Per Slide

| Slide Type | Maximum Content |
|------------|-----------------|
| Title slide | 1 heading + 1 subtitle + optional tagline |
| Content slide | 1 heading + **3-4 bullets** (max 2 lines each) OR 1 heading + 2 short paragraphs |
| Feature grid | 1 heading + **max 6 cards** (2x3 or 3x2) — prefer 4 on short screens |
| Code slide | 1 heading + 8-10 lines of code maximum |
| Quote slide | 1 quote (max 3 lines) + attribution |
| Image slide | 1 heading + 1 image (max 50vh height) |
| Multi-section slide | **≤2 sections stacked.** Hero + one grid, or hero + one card — NOT hero + flow + grid + callout. Split any slide that has 3+ distinct content blocks. |

**Too much content? → Split into multiple slides, grouped by meaning.**

### Required Tailwind Base Classes

Prefer the shared `<Slide>` component; the classes below are for rare hand-rolled slides. Pagination invariants (data-slide / asymmetric padding / transform-track) are in `SKILL.md`.

```tsx
<section data-slide className={cn(
  // Fill the track slot. Do NOT use `h-dvh`/`h-svh`/`h-screen` — invariant #3.
  "w-full h-full shrink-0 overflow-hidden flex flex-col relative",
  "px-[var(--ppt-pad-x)] pt-[var(--ppt-pad-top)] pb-[var(--ppt-pad-bottom)]"
)}>
  <div className="flex-1 flex flex-col justify-center max-h-full overflow-hidden">

// Typography — `min(vw, vh)` so fonts shrink when the viewport is short, not just narrow
<h1 className="text-[clamp(1.5rem,min(5vw,8vh),4rem)]">
<h2 className="text-[clamp(1.25rem,min(3.5vw,6vh),2.5rem)]">
<p className="text-[clamp(0.75rem,min(1.5vw,2.5vh),1.125rem)]">
```

### Viewport Fitting Checklist

Before finalizing any slide, confirm each item:

- [ ] Slide root uses `w-full h-full shrink-0` (invariant #3) — NOT `h-dvh`/`h-svh`/`h-screen`
- [ ] `data-slide` present on the slide root (invariant #1)
- [ ] Padding via `--ppt-pad-*` CSS vars, not symmetric `p-[...]` (invariant #5)
- [ ] Typography uses `clamp(min, min(Xvw, Yvh), max)` — both axes (invariant #6)
- [ ] Per-slide density respects the table above
- [ ] ≤2 stacked content blocks (split hero+flow+grid+callout)
- [ ] Images capped at `max-h-[min(50vh,400px)]`
- [ ] Grids use responsive columns that stack on mobile
- [ ] Long tables/code split across slides by meaning (distinct sub-title per part)
- [ ] Cross-slide header spec (chapter number, kicker, accent) is identical on every content slide (invariant #7)

---

## Theme Selection Guide

| If the user wants... | Recommend... |
|---------------------|--------------|
| "Professional but not boring" | Bold Signal |
| "Techy/futuristic" | Neon Cyber or Terminal Green |
| "Elegant/luxury" | Dark Botanical or Paper & Ink |
| "Friendly/approachable" | Pastel Geometry or Notebook Tabs or Split Pastel |
| "Minimal/clean" | Swiss Modern or Paper & Ink or Electric Studio |
| "Creative/playful" | Pastel Geometry or Creative Voltage or Split Pastel |
| "Editorial/magazine" | Vintage Editorial or Paper & Ink or Notebook Tabs |

### Available Themes

| Theme | Vibe | Best For |
|-------|------|----------|
| `bold-signal` | Confident, bold, high-impact | Pitch decks, keynotes |
| `electric-studio` | Clean, high-contrast, professional | Product launches, agency decks |
| `creative-voltage` | Energetic, retro-modern, electric | Creative pitches, brand decks |
| `dark-botanical` | Elegant, warm luxury | Premium brands, lifestyle |
| `neon-cyber` | Futuristic, techy | Tech startups, AI products |
| `terminal-green` | Hacker aesthetic | Dev tools, APIs, CLI |
| `notebook-tabs` | Editorial, organized | Reports, documentation |
| `pastel-geometry` | Friendly, playful | Onboarding, consumer apps |
| `split-pastel` | Playful, friendly, two-tone | Consumer apps, product overviews |
| `vintage-editorial` | Witty, confident, personality-driven | Storytelling, lifestyle editorial |
| `swiss-modern` | Minimal, Bauhaus | Corporate, data-focused |
| `paper-ink` | Literary, timeless | Storytelling, thought leadership |

### Font Pairing Quick Reference

| Theme | Display Font | Body Font |
|-------|--------------|-----------|
| Bold Signal | Archivo Black | Space Grotesk |
| Electric Studio | Manrope (800) | Manrope (400/500) |
| Creative Voltage | Syne | Space Mono |
| Dark Botanical | Cormorant | IBM Plex Sans |
| Neon Cyber | Unbounded | Manrope |
| Terminal Green | JetBrains Mono | JetBrains Mono |
| Notebook Tabs | Bodoni Moda | DM Sans |
| Pastel Geometry | Plus Jakarta Sans | Plus Jakarta Sans |
| Split Pastel | Outfit (700/800) | Outfit (400/500) |
| Vintage Editorial | Fraunces | Work Sans |
| Swiss Modern | Archivo | Nunito |
| Paper & Ink | Cormorant Garamond | Source Serif 4 |

### 字体加载 + Tailwind 布线（必做）

所有字体走妙搭代理 `miaoda.feishu.cn/fonts`，用法与 Google Fonts 完全一致，**禁止直连 `fonts.googleapis.com`**。字体名里的空格用 `+` 替代。

**在 `client/src/tailwind-theme.css` 做 3 件事**（缺任何一件字体都不生效）：

```css
/* 1. 顶部 @import 下载字体资源（示例：Bold Signal） */
@import url('https://miaoda.feishu.cn/fonts/css2?family=Archivo+Black&family=Space+Grotesk:wght@400;500;700&display=swap');

@tailwind base;
@tailwind components;
@tailwind utilities;

/* 2. :root 注册 CSS 变量：Display 进 --font-display，Body 进 --font-sans */
:root {
  --font-display: 'Archivo Black', sans-serif;   /* 标题 */
  --font-sans: 'Space Grotesk', sans-serif;       /* 正文 = body 默认 */
}

/* 3. @theme inline 注册成 Tailwind utility（让 className="font-display" 生效） */
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```

**使用规则：**

| 元素 | className | 渲染字体 |
|------|-----------|---------|
| 标题 h1/h2/h3、大字号装饰、节号 | `font-display` | Display |
| 正文 p、UI 控件、默认 | 不加任何 `font-*` 类 | Body（`--font-sans`） |
| 代码块、键盘符 | `font-mono`（仅 Terminal Green 需要主题级） | Mono |

**硬性禁止：**
- ❌ `style={{ fontFamily: '...' }}` inline 样式——绕过 Tailwind token，写法撕裂
- ❌ 自建 `--ppt-font-display` / `--ppt-font-body` 页面级变量——与 Tailwind 脱节
- ❌ 把 Display 字体塞进 `--font-serif`，哪怕它本身就是 serif——统一用 `font-display`，全主题一套写法
- ❌ `font-serif` utility 出现在业务 slide 里——只允许出现在 shadcn/ui 自带组件
- ❌ 字体名拼错或空格没转 `+`（`family=Space+Grotesk` ✓，`family=Space Grotesk` ✗）

---

## ⚠️ After selecting a theme

Read the full theme details from:

```
references/themes/{theme-name}.md
```

Example: if you chose `neon-cyber`, read `references/themes/neon-cyber.md` for CSS variables, Tailwind classes, and signature elements.

---

## Animation Presets

### Entrance Animations (Framer Motion)

```tsx
const fadeUp = { hidden: { opacity: 0, y: 30 }, visible: { opacity: 1, y: 0 } };
const scaleIn = { hidden: { opacity: 0, scale: 0.9 }, visible: { opacity: 1, scale: 1 } };
const slideLeft = { hidden: { opacity: 0, x: -50 }, visible: { opacity: 1, x: 0 } };
const blurIn = { hidden: { opacity: 0, filter: 'blur(10px)' }, visible: { opacity: 1, filter: 'blur(0px)' } };
const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.2 } }
};
```

### Easing & Timing

```tsx
ease: [0.16, 1, 0.3, 1]        // easeOutExpo — recommended for most
ease: [0.68, -0.55, 0.265, 1.55] // easeOutBack — playful themes
ease: [0.25, 0.1, 0.25, 1]     // easeOutCubic — snappy, professional
```

| Theme Type | Duration | Stagger |
|------------|----------|---------|
| Professional | 0.4-0.5s | 0.05-0.1s |
| Playful | 0.5-0.7s | 0.1-0.15s |
| Dramatic | 0.8-1.2s | 0.15-0.2s |
| Minimal | 0.3-0.4s | 0.05s |

---

## Style Effect → Feeling Mapping

| Feeling | Effects |
|---------|---------|
| Dramatic/Cinematic | Slow fade-ins, scale transitions, dark backgrounds, parallax |
| Techy/Futuristic | Neon glows, grid patterns, monospace accents, cyan/magenta |
| Playful/Friendly | Bouncy easing, large radius, pastels, floating animations |
| Professional/Corporate | Subtle/fast animations, navy/slate, precise spacing |
| Calm/Minimal | Very slow motion, whitespace, muted colors, serifs |
| Editorial/Magazine | Strong typography, pull quotes, grid-breaking, serif headlines |
