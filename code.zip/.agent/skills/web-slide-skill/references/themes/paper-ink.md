# Theme: Paper & Ink

**Vibe:** Literary, thoughtful, editorial, timeless

**Best For:** Storytelling, narratives, thought leadership

**Typography:**
- Display: `Cormorant Garamond` (500/700) — elegant editorial serif
- Body: `Source Serif 4` (400/500) — readable text serif

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Cormorant+Garamond:wght@500;700&family=Source+Serif+4:wght@400;500&display=swap');

:root {
  --font-display: 'Cormorant Garamond', Georgia, serif;
  --font-sans: 'Source Serif 4', Georgia, serif;  /* body 也是 serif */
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_标题用 `className="font-display"`，正文不加字体类（body 默认就是 Source Serif 4）。_

**Theme CSS:**
```css
[data-ppt-theme="paper-ink"] {
  --ppt-bg: #fdfcf9;
  --ppt-bg-secondary: #f5f3ee;
  --ppt-text: #2c2c2c;
  --ppt-text-secondary: #6b6b6b;
  --ppt-accent: #1a1a1a;
  --ppt-rule: #d4d4d4;
}
```

**Key Tailwind Classes:**
```tsx
// Paper background
className="bg-[var(--ppt-bg)] text-[var(--ppt-text)]"

// Serif typography
className="font-display text-[clamp(1.5rem,4vw,3rem)] leading-relaxed"

// Horizontal rules
className="w-24 h-px bg-[var(--ppt-rule)] my-8"

// Pull quote
className="font-display italic text-[clamp(1.25rem,3vw,2rem)] border-l-2 border-[var(--ppt-accent)] pl-6"
```

**Signature Elements:**
- Elegant serif typography
- Generous whitespace
- Horizontal rules as dividers
- Pull quotes with border
- No decorative elements — content focused
