# Theme: Electric Studio

**Vibe:** Bold, clean, professional, high-contrast

**Best For:** Product launches, agency decks, brand intros

**Typography:**
- Display: `Manrope` (800) — geometric sans, single family
- Body: `Manrope` (400/500)

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Manrope:wght@400;500;800&display=swap');

:root {
  --font-display: 'Manrope', sans-serif;
  --font-sans: 'Manrope', sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_单字体多字重；标题用 `font-display` + `font-extrabold`，正文不加字体类。_

**Theme CSS:**
```css
[data-ppt-theme="electric-studio"] {
  --ppt-bg-dark: #0a0a0a;
  --ppt-bg-white: #ffffff;
  --ppt-accent: #4361ee;         /* electric blue */
  --ppt-text-dark: #0a0a0a;
  --ppt-text-light: #ffffff;
  --ppt-accent-bar: #4361ee;
}
```

**Key Tailwind Classes:**
```tsx
// Two-panel vertical split (white top, blue bottom)
className="min-h-full grid grid-rows-[3fr_2fr]"
// top: bg-[var(--ppt-bg-white)]  bottom: bg-[var(--ppt-accent)]

// Edge accent bar
className="absolute left-0 top-0 bottom-0 w-1 bg-[var(--ppt-accent-bar)]"

// Hero quote
className="font-display text-[clamp(2rem,6vw,5rem)] font-extrabold leading-tight tracking-tight"
```

**Signature Elements:**
- Two-panel vertical split (white + accent color)
- Thin accent bar on panel edge
- Quote typography as hero
- Corner brand marks
- Minimal, confident spacing
