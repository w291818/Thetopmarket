# Theme: Swiss Modern

**Vibe:** Minimal, precise, Bauhaus-inspired

**Best For:** Corporate presentations, data-focused, professional

**Typography:**
- Display: `Archivo` (800) — geometric with tight tracking
- Body: `Nunito` (400) — clean humanist sans

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Archivo:wght@800&family=Nunito:wght@400;500&display=swap');

:root {
  --font-display: 'Archivo', sans-serif;
  --font-sans: 'Nunito', sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_标题用 `className="font-display"`，正文不加字体类。_

**Theme CSS:**
```css
[data-ppt-theme="swiss-modern"] {
  --ppt-bg: #ffffff;
  --ppt-bg-secondary: #f8f8f8;
  --ppt-text: #1a1a1a;
  --ppt-text-secondary: #666666;
  --ppt-accent: #ff0000;
  --ppt-border: #e0e0e0;
}
```

**Key Tailwind Classes:**
```tsx
// Clean layout
className="bg-[var(--ppt-bg)] text-[var(--ppt-text)]"

// Red accent (Swiss style)
className="bg-[var(--ppt-accent)] text-white"

// Grid lines
className="border-t border-[var(--ppt-border)]"

// Tight typography（Archivo 800，Bauhaus 大标题）
className="font-display text-[clamp(2rem,6vw,5rem)] font-extrabold tracking-tight leading-none"
```

**Signature Elements:**
- High contrast black/white with red accent
- Strong grid alignment
- Geometric shapes
- Minimal decoration
