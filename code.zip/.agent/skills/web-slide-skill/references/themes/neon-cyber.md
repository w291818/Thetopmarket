# Theme: Neon Cyber

**Vibe:** Futuristic, techy, cutting-edge

**Best For:** Tech startups, AI products, dev tools

**Typography:**
- Display: `Unbounded` (600/700) — futuristic geometric display
- Body: `Manrope` (400/500) — clean modern sans
- Accents: `font-mono` for tech feel

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Unbounded:wght@600;700&family=Manrope:wght@400;500&display=swap');

:root {
  --font-display: 'Unbounded', sans-serif;
  --font-sans: 'Manrope', sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_标题用 `className="font-display"`，正文不加字体类，代码/徽章用 `font-mono`。_

**Theme CSS:**
```css
[data-ppt-theme="neon-cyber"] {
  --ppt-bg: #0a0f1c;
  --ppt-bg-secondary: #111827;
  --ppt-text: #ffffff;
  --ppt-text-secondary: #9ca3af;
  --ppt-accent: #00ffcc;
  --ppt-accent-glow: rgba(0, 255, 204, 0.3);
  --ppt-accent-secondary: #ff00aa;
}
```

**Key Tailwind Classes:**
```tsx
// Neon glow effect
className="text-[var(--ppt-accent)] drop-shadow-[0_0_20px_var(--ppt-accent-glow)]"

// Grid background
className="bg-[var(--ppt-bg)] bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]"

// Accent badges
className="bg-[var(--ppt-accent)]/10 text-[var(--ppt-accent)] border border-[var(--ppt-accent)]/30 rounded-full px-4 py-1 font-mono text-sm"
```

**Signature Elements:**
- Neon glow effects (cyan, magenta)
- Grid pattern backgrounds
- Monospace accents
- Glitch or scramble effects (optional)
