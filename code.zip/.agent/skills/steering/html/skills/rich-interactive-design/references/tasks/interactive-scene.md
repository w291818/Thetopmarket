# Interactive Scene Design

HTML 单文件 3D / 沉浸式场景类的专属设计决策。覆盖自然场景（山脉、海洋、星空）、产品展示（360° 旋转预览）、虚拟漫游（建筑、虚拟展厅）、抽象空间（数据结构 3D 可视化、概念演示）等"用户探索 + 美学体验"为主的场景。

与 `simulation` 的本质区别：**简单系统下的强视觉/强空间感**，而非"模拟系统行为"。与 `game` 的本质区别：**没有挑战与胜负**。

## Quick Reference

| 决策 | 默认 | 例外 |
|---|---|---|
| 技术栈 | **Three.js** | 用户明确要 Babylon / WebGPU 时尊重 |
| 相机控制 | OrbitControls + 阻尼 + 移动端 touch 支持 | 第一人称漫游 → PointerLockControls；纯展示无交互 → 仅自动旋转 |
| 加载体验 | **必有 loading 进度**（黑/纯色屏 + 进度数字），禁直接白屏到首帧 | 加载 < 200ms 可省 |
| 光照基础 | 至少 1 直射 + 1 环境，禁纯 ambient 全亮 | 卡通/扁平风格可调整 |
| 材质 | **MeshStandardMaterial**（PBR） 默认，不要 MeshBasicMaterial 当主材质 | 程式化/极简风格除外 |
| 性能预算 | Draw calls ≤ 100；总顶点 ≤ 500k；纹理总和 ≤ 32MB | 移动端各砍半 |
| 资源释放 | 切换 / 销毁场景必须 `geometry.dispose()` + `material.dispose()` + `texture.dispose()` | — |
| Pixel Ratio | `min(devicePixelRatio, 2)`，不能直接用 dpr | — |
| 移动端 | `touch-action: none` + 双指缩放手势 + 减面减分辨率 | — |

## 1. 场景类型识别

从用户描述推三个维度，得出**一句话定位**写进 plan：

| 维度 | 取值 |
|---|---|
| 场景内容 | 自然（地形/天空/海/植物）/ 产品（单物体展示/对比）/ 建筑空间（漫游/导览）/ 抽象（数据/概念可视化）/ 抽象艺术（生成几何/参数化） |
| 用户角色 | 观看（仅看自动巡游）/ 操控相机（轨道旋转、缩放、平移）/ 漫游（第一人称走动）/ 探索（点击热点、模式切换、对比） |
| 时间维度 | 静态（无演化）/ 周期演化（昼夜、季节、潮汐自动循环）/ 用户驱动演化（拨滑块控制时间） |

输出例：

- "自然 + 操控相机 + 周期演化 → 3D 自然景观（山脉昼夜、海洋日落）"
- "产品 + 操控相机 + 静态 → 商品 3D 展示（鞋、车、家具）"
- "建筑空间 + 漫游 + 静态 → 虚拟展厅 / 房屋导览"
- "抽象 + 探索 + 静态 → 3D 数据可视化（节点图、力导向）"
- "抽象艺术 + 观看 + 周期演化 → 生成艺术展示"

这三维度直接决定 §3 相机方案、§5 光照与时间、§6 交互层。

**禁止组合**（违反认知）：商品展示 × 阴森暗光 / 自然景观 × 霓虹紫粉 / 严肃数据可视化 × 卡通材质 / 建筑漫游 × 强烈鱼眼变形。

## 2. 资源加载与首屏

3D 场景的杀手用户体验 = **白屏 → 突然出现完整场景**。必须有过渡：

### 加载状态（必备）

```js
const loadingManager = new THREE.LoadingManager(
  () => fadeOutLoadingScreen(),        // 全部加载完
  (url, loaded, total) => updateProgress(loaded / total)  // 进度更新
);
const textureLoader = new THREE.TextureLoader(loadingManager);
const gltfLoader = new GLTFLoader(loadingManager);
```

页面打开 → 全屏纯色 + 进度条/数字 → 加载完 fade out → 场景渐现（0.5s）。**禁止**首帧白屏到画面突现。

### 资源策略

- 模型：`.glb` 二进制格式（不要 `.gltf` + 分离的 bin），DRACO 压缩可选
- 纹理：`.webp` 优先，回退 `.jpg`；HDR 环境贴图用 `.hdr` 或 RGBM `.png`
- 资源体积控制：单纹理 ≤ 4MB，总场景 ≤ 32MB（移动端 ≤ 16MB）
- CDN 路径：自由选用 jsDelivr / Three.js 官方 examples，禁占位图外链

## 3. 相机控制

按用户角色（§1）选控制器：

| 用户角色 | 控制器 | 关键配置 |
|---|---|---|
| 观看 | 无控制器 + 自动 `orbit` 缓慢自转 | rotation per frame ≈ 0.001 rad |
| 操控相机 | **OrbitControls** | `enableDamping = true`、`dampingFactor = 0.05`、限制 polarAngle 防止穿地 |
| 漫游 | PointerLockControls + WASD + 重力 | 桌面专属；移动端退化为虚拟摇杆 |
| 探索 | OrbitControls + 点击切视角（tween 过渡） | 视角切换手写 lerp + easing 函数（如 `easeInOutCubic`），禁瞬移； |

### 必备约束

- **限制角度**：地面场景 polarAngle ∈ [10°, 80°]，禁止看到地面以下
- **限制距离**：min/max distance 防止穿物体或飞到太空
- **阻尼**：`enableDamping` 让操作有惯性感，不要瞬停
- **重置视角按钮**：用户飞偏了能一键回到初始视角，tween 0.6s

### 移动端

- `touch-action: none`（防 swipe 触发页面滚动）
- 双指缩放 + 单指拖拽旋转 + 双指拖拽平移（OrbitControls 默认支持）
- 灵敏度移动端略低于桌面（避免误触）

## 4. 渲染与性能

### Pixel Ratio

```js
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
```

不要 `setPixelRatio(window.devicePixelRatio)`——4K 屏 dpr = 2 但有些手机 dpr = 3 或 4，纯按 dpr 渲染量爆炸卡死。

### Draw Call 预算

- 桌面 ≤ 100，移动端 ≤ 50
- 多个相同物体用 **InstancedMesh** 合并（一次 draw call 渲染 N 个）
- 静态场景用 **BufferGeometryUtils.mergeBufferGeometries** 合并相邻 mesh

### LOD（细节层次）

镜头远了切低面模型，近了切高面：

```js
const lod = new THREE.LOD();
lod.addLevel(highMesh, 0);
lod.addLevel(midMesh, 50);
lod.addLevel(lowMesh, 200);
```

地形/植被类场景必用 LOD，否则远处大片高面物体把性能拖垮。

### 移动端优化

- 减半渲染分辨率：`renderer.setSize(w * 0.7, h * 0.7)` + CSS 拉伸
- 关闭阴影或用低分辨率阴影（`shadow.mapSize = 512`）
- 减少粒子数 / 关闭高级后期（bloom、SSAO）

### 资源释放（切场景 / 销毁必做）

```js
function disposeScene(scene) {
  scene.traverse((obj) => {
    if (obj.geometry) obj.geometry.dispose();
    if (obj.material) {
      const m = obj.material;
      Object.values(m).forEach(v => v?.isTexture && v.dispose());
      m.dispose();
    }
  });
}
```

不 dispose 切场景一次内存涨几十 MB，第三次切就 crash。

## 5. 光照与时间演化

### 光照基础组合

| 场景类型 | 推荐光照 |
|---|---|
| 室外自然 | DirectionalLight（太阳）+ HemisphereLight（天空 + 地面色） |
| 室内/产品 | 3 点布光：主光（DirectionalLight）+ 辅光（DirectionalLight 弱）+ 边缘光 |
| 程式化/极简 | AmbientLight + 1 DirectionalLight |
| 写实 | EnvironmentMap（HDR）+ DirectionalLight 阳光，PMREMGenerator 预处理 |

**禁止**：纯 AmbientLight 全亮（场景扁平无立体）；强度全开（>2 的 intensity 让金属材质曝白）

### 昼夜 / 周期演化

时间演化场景（§1 时间维度 = 周期演化 / 用户驱动）必做：

- 太阳位置随时间在天穹上扫弧
- 太阳颜色：日出/日落 `0xffaa44` 暖橙 → 正午 `0xfff5e0` 暖白 → 夜晚 `0x223366` 冷蓝
- 天空颜色用 `Sky` shader（Three.js examples 自带）或自实现 fragment shader 上下渐变
- 环境光强度随昼夜变化（夜晚 0.2，正午 0.6）
- 用户驱动：滑块 ∈ [0, 24]，实时更新太阳与光色

## 6. 交互层与模式切换

3D 场景"沉浸"之上还得"可探索"。常用交互模式：

### 热点 / 信息点

- 用 `Sprite` + 透明纹理或 HTML overlay（CSS `position: absolute` + WebGL 坐标 → 屏幕坐标投影）
- 点击触发面板弹出 / tween 相机到该位置
- 移动端用 `touchend`，不用 `click`（300ms 延迟会让用户觉得卡）

### 模式切换（如等高线 / 线框 / 透明）

- 切换按钮浮在右上角，托盘式 UI
- 等高线：自实现 fragment shader 用 `fract(vWorldPosition.y * lineFreq)` 阈值判定，比加 mesh 高效
- 线框：`material.wireframe = true`（最简但低质感），或自实现 fragment shader 画边
- 透明 / X 光：调 `material.opacity` + `transparent: true` + `depthWrite: false`

### Raycaster 点击拾取

```js
const raycaster = new THREE.Raycaster();
raycaster.setFromCamera(pointer, camera);
const hits = raycaster.intersectObjects(targets, false);
```

`targets` 显式列出可点物体，**不要** `intersectObjects(scene.children, true)`——递归遍历整个场景每帧爆炸。

### 自动巡游 / 相机动画

观看类场景默认应该有"惊艳首屏"动画：开局相机从远处缓慢推近 + 轻微环绕，2-3 秒后停止让用户接管。

## 7. 视觉风格

### 风格倾向

| 场景类型 | 推荐风格 |
|---|---|
| 自然景观 | 写实 PBR + HDR 环境光 + 真实大气散射 |
| 产品展示 | 干净 studio 灯光（HDR studio.hdr）+ 浅灰/纯色背景 + 柔和阴影 |
| 建筑漫游 | 写实 PBR + 真实材质（混凝土、玻璃、木）+ 局部强调灯 |
| 抽象数据 | 暗底 + 高饱和发光（emissive + bloom 后期） |
| 生成艺术 | 极简几何 + 程式化材质 + 大胆配色 |

### 后期处理（按需）

`EffectComposer` + `UnrealBloomPass`（发光）/ `SMAAPass`（抗锯齿）/ `SSAOPass`（环境光遮蔽）

不要默认全开后期——移动端会爆。只在视觉受益大的场景加（如夜景发光、暗调氛围）。

## 场景特有反模式

- **白屏到首帧突现**——没有 loading 进度
- **纯 AmbientLight 全亮**——画面扁平如纸片
- **MeshBasicMaterial 当主材质**——无光照响应，看着像未渲染
- **Canvas 2D / 程序化生成写实物体纹理（地球、月球、人脸、汽车、知名建筑等"用户脑中有真实标准答案"的物体）**——一定会被识破为假；必须用 CDN 真实贴图
- **不 dispose**——切场景内存爆炸，几次后 crash
- **`setPixelRatio(devicePixelRatio)`**——高 dpr 手机直接卡死
- **OrbitControls 不限制 polarAngle**——用户翻到地下看到悬空模型
- **Raycaster 每帧 `intersectObjects(scene.children, true)`**——递归全场景 60 次/秒
- **render loop 里 `new THREE.Vector3()`**——GC 风暴
- **移动端不 `touch-action: none`**——拖拽场景同时滚动页面
- **桌面 / 移动同一套灵敏度**——手机操作太灵或太钝
- **加载完场景突现无过渡**——0 帧 fade in 突兀
- **太阳颜色一日不变**——黄昏还是白光太阳，假
- **后期 bloom 强度 > 2**——所有亮处都晕成一团白

## Worked Example

> 用户输入："3D HTML 山脉场景，含悬崖、河流、昼夜光照变化。支持拖动缩放、动画过渡、真实感渐变色，可切换等高线显示。"
>
> **§1 类型识别**：自然 + 操控相机 + 周期演化 + 探索（等高线切换）→ 「3D 自然景观 + 时间演化 + 模式切换」
>
> **§2 加载**：LoadingManager 接 TextureLoader（地形 heightmap、岩石/草地纹理、HDR 天空）；纯黑屏 + 进度数字 → 加载完 fade out 0.5s → 场景 fade in
>
> **§3 相机**：OrbitControls，dampingFactor 0.05；polarAngle ∈ [10°, 80°] 防穿地；min/max distance 限制；右上角"重置视角"按钮 tween 0.6s
>
> **§4 性能**：
>
> - 地形：PlaneGeometry 256×256 段，displacement 用 heightmap 纹理（不用 vertex 数组手动算）
> - LOD：远景地形 64×64 段切换
> - InstancedMesh：树木 / 岩石散布 500 个，单 draw call
> - PixelRatio `min(dpr, 2)`；移动端 `setSize(w * 0.7, h * 0.7)` + CSS 拉伸
> - 阴影：DirectionalLight casts shadow，`shadow.mapSize = 1024`（移动端 512）
>
> **§5 光照与时间**：
>
> - DirectionalLight 太阳 + HemisphereLight 天空-地面光
> - Sky shader（Three.js examples）+ Sun position 联动
> - 滑块 0-24 控制时间：日出 (5h) 暖橙 → 正午 (12h) 暖白 → 黄昏 (18h) 深橙 → 夜 (22h) 冷蓝 + 月光弱直射
> - 自动循环模式：勾选后时间自动以 1 分钟/天 流逝
>
> **§6 交互层**：
>
> - 模式切换托盘（右上角）：默认渲染 / 等高线 / 线框
> - 等高线模式：fragment shader 用 `step(0.05, fract(vWorldPosition.y * 0.1))` 画等高线 + 高度颜色映射（viridis）
> - 河流：PlaneGeometry + 水 shader（动画 uv 偏移 + 法线扰动 + 透明 + 反射环境）
> - 拖拽 / 缩放：OrbitControls 自动支持桌面 + 移动 touch
>
> **§7 视觉**：写实 PBR + HDR 环境光（开源 venice_sunset.hdr 或类似）；地形材质用 splat map（草 / 岩 / 雪按高度混合）
>
> **反模式提醒**：
>
> - 必须 `min(dpr, 2)` 不能直接 dpr
> - 必须 dispose geometry/material/texture（虽然这是单场景，但树木 InstancedMesh 需要正确释放）
> - Raycaster 不要每帧全场景遍历——本例没有点击拾取，可省
> - 太阳颜色不能恒定，必须随时间变
> - 必须有 loading 进度
>
> **不要照抄此例**——同样需求换成"低多边形风格 + 程式化生成地形（noise）"也合理。按 §1-§7 维度从本任务重新推导。
