# Image Generation

游戏 / 模拟 / 沉浸场景的 `GenerateImage` 用法。**优先程序化生成**（SVG / Canvas / Three.js Geometry / shader 等，详见各 task 文件），本文聚焦确实需要调 GenerateImage 时的 prompt 公式与开关。

## prompt 构造公式

按以下公式分段构造，每段从本任务推导：

```
[主体描述] + [风格词] + [构图] + [配色/光线] + 通用尾部
```

| 部分 | 推导依据 | 示例 |
|---|---|---|
| 主体 | 任务的"内容"维度 | "8-bit pixel game character"、"cyberpunk neon city skyline"、"3D mountain landscape at dawn"、"abstract fluid simulation cover" |
| 风格词 | 各 task 文件 §视觉风格 已推 | "pixel 16-bit"、"flat cartoon"、"minimalist geometric"、"neon cyber"、"photorealistic PBR" |
| 构图 | 用途决定 | sprite → "centered, transparent background"；场景 → "wide cinematic angle"；封面 → "16:9 hero composition"；seamless 纹理 → "seamless tileable" |
| 配色 / 光线 | 主色 + 风格派生 | "warm earth tones"、"high contrast neon"、"soft natural lighting"、"dramatic rim light"、"HDR studio lighting" |

通用尾部**按用途选一种**：

- Sprite / 角色 / 物件：`flat icon, transparent background, game asset, no text overlay, no UI mockup`
- 场景 / 背景 / 封面：`16:9, high resolution, no text overlay, no UI mockup, no AI watermark`
- Seamless 纹理：`seamless tileable pattern, no obvious seams, high resolution`

## 各任务生图开关

| 任务 | 默认 GenerateImage | 适用场景 | 风格倾向 |
|---|---|---|---|
| `game` | **主动调** | sprite / 角色 / 敌人 / 道具 / 关卡背景 / 封面 | 跟随 game.md §5 推出的风格词，使用 game asset 通用尾部；详细公式见 game.md §5 |
| `interactive-scene` | **按需** | 环境 HDR 风格图 / 关键背景 / 产品场景照 / 抽象艺术封面 | 跟随 interactive-scene.md §7 推出的风格词；写实场景倾向 PBR / studio / 自然光关键词 |
| `simulation` | **极少**（默认全程式化）| 仅"科学可视化的封面图" / 抽象艺术化模拟的视觉调性参考 | 抽象克制，**禁营销词**（"震撼"/"未来感"/"活力"），用 "scientific visualization"、"abstract data art"、"minimal generative" 等 |

## 风格一致性纪律

同一作品多次调用 GenerateImage 时（如游戏的多个角色、场景的多张参考图），prompt 内**必须包含相同的风格描述词**（如统一带 "pixel 16-bit, warm earth tones"），避免画风分裂。

## 通用禁令

- `<img>` alt 必须有意义，描述图片内容，禁空 alt / 文件名
- 禁用 placeholder.com / unsplash 等外链占位服务
- 生成结果以 base64 data URL 嵌入 HTML，**禁外链**（详见各 task 文件资产策略）
- 不要在生成尾部加 "epic / cinematic / masterpiece" 等大词，产出反而失控（详见 game.md "生图 prompt 写'epic game hero cinematic scene'——产出电影海报而非可用素材" 反模式）
