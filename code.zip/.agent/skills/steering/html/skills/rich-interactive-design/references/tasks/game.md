# Game Design

HTML 单文件游戏 / 互动玩法的专属设计决策。

## Quick Reference

| 决策 | 默认 | 例外 |
|---|---|---|
| 类型识别 | 见 §1 三维度推导 | 用户已指定具体玩法 → 直接尊重 |
| 渲染层 | 见 §3 决策树 | 用户指定 Canvas / DOM → 尊重 |
| 状态机 | 4 态必有：menu / playing / paused / over | 回合驱动游戏可省 paused |
| "再来一局" | **必须 reset 全部状态**，禁 `location.reload()` | — |
| 输入支持 | 桌面键鼠 + 移动 touch **必须同时** | 用户明确单端时尊重 |
| 关键反馈延迟 | ≤ 100ms | — |
| 最高分 | 持久化到 localStorage | 用户明确不需要 |
| 素材 | 主动调 `GenerateImage` 产精灵 / 背景 / UI | 用户已提供 / 玩法不需要素材 |

## 1. 游戏类型识别

从用户描述推三个维度，每次得出**一句话定位**写进 plan：

| 维度 | 取值 |
|---|---|
| 实时性 | 实时连续帧（每秒重绘）/ 回合驱动（仅在用户输入后更新） |
| 状态离散度 | 离散格子（棋盘/网格/卡牌）/ 连续物理（位置 / 速度浮点）/ 表单选择（题目 / 选项） |
| 主输入通道 | 方向键 WASD / 单击 / 拖拽 / 滑动手势 / 鼠标移动追踪 / 选择题点击 |

输出例：

- "回合驱动 + 离散网格 + 滑动手势 → 合并解谜类（2048）"
- "实时连续 + 连续物理 + 方向键 → 横版动作 / 跑酷"
- "回合驱动 + 表单选择 + 点击 → 多步答题 / 剧情分支"
- "实时连续 + 离散网格 + 单击 → 打地鼠 / 反应速度类"

这三个维度直接决定 §3 渲染层、§4 输入、§5 视觉。

**禁止组合**（违反认知）：益智解谜 × 抖屏闪光 / 儿童益智 × 暗黑血腥 / 慢节奏阅读 × 高刺激粒子 / 单功能反应训练 × 复杂剧情。

## 2. 核心循环与状态机

### 4 态状态机（强制）

```
menu  ──start──▶  playing  ──pause──▶  paused
                     │  ◀──resume──┘
                     │
                     └──lose/win──▶  over  ──restart──▶  playing
```

每个状态都要有清晰的回退路径，禁"卡死"无出口的中间态。回合驱动游戏可省 paused（玩家自然停手即是暂停）。

### 核心循环契约

- **反馈窗口**：用户输入到屏幕产生**任何**视觉变化 ≤ 100ms。粒子 / 数字弹出 / 缩放 / 颜色脉冲任选一种作为"打击感"
- **"再来一局"必须 reset 整局状态**：分数清零、棋盘清空、计时器重置。**禁用** `location.reload()` 当重启——交互契约要求按钮真实工作，而非粗暴刷新页面
- **暂停态**：实时类游戏必须暂停时停止主循环（`cancelAnimationFrame`），不是把 dt 设 0 继续空转；回合类不需要暂停
- **结束态**：必须有 Game Over 面板（本局分数 + 最高分 + 再来一局按钮），**禁用** `alert()` / `confirm()` 报分或问"是否重玩"

### 主循环写法

实时类用 `requestAnimationFrame`，**禁** `setInterval` 当主循环（与刷新率失同步 / Tab 失焦累积）。回合类无需主循环，事件驱动即可——不要为了"像游戏"硬塞 rAF。

## 3. 渲染选择决策树

按三问决定渲染层，**不要默认 Canvas**：

1. **状态是否离散网格？** 是 → DOM
2. **是否需要每帧重绘连续动画？** 是 → Canvas
3. **是否纯静态形状 + 简单过渡？** 是 → SVG / CSS 动画即可

| 类型推导（§1） | 推荐层 |
|---|---|
| 回合 + 离散网格（2048 / 三消 / 推箱子 / 卡牌） | **DOM 网格** |
| 实时 + 连续物理（跑酷 / 打砖块 / 弹幕） | **Canvas 2D** |
| 实时 + 离散网格（打地鼠） | **DOM**；动画密集才 Canvas |
| 回合 + 表单选择（答题 / 剧情） | **DOM 表单 + 状态** |
| 静态几何 + 过渡（拼图慢动作） | **SVG** 或 CSS |

DOM 网格常见误区：用 `position: absolute` 配像素 left/top 排格子。改用 **CSS Grid**（`grid-template-columns: repeat(N, 1fr)`），每格是 grid item，合并/移动用 `transform` + `transition`。

## 4. 双端输入设计

HTML 单文件不能预设设备，桌面键鼠 + 移动 touch **必须同时**支持，**除非**用户明确说"只做桌面 / 只做移动"。

### 输入通道映射

| 主输入（§1 推出） | 桌面绑定 | 移动绑定 |
|---|---|---|
| 方向键 / WASD | `keydown` | 屏幕方向虚拟键 **或** 画布 swipe 手势 |
| 单击 / 选择题 | `click` | `click`（浏览器自动合成） |
| 拖拽 | `mousedown/move/up` | `touchstart/move/end`（或 Pointer Events 统一） |
| 滑动手势（2048 类） | 方向键 `keydown` + 画布 swipe | 画布 swipe |
| 鼠标移动追踪 | `mousemove` | 退化为 `touchmove` 拖拽 |

优先 **Pointer Events** 统一两端，减少分支。

### 移动端额外约束

- 游戏容器加 `user-select: none; touch-action: none;`——防止长按选中、防止 swipe 触发页面滚动
- 顶部留出 safe area：`padding-top: env(safe-area-inset-top)`
- 移动端字号 ≥ 14px，按钮触控区 ≥ 44 × 44px

## 5. 视觉风格与游戏素材生图

### 风格选择（从 §1 类型推一句话风格词）

常见方向（任选其一，**不要混风格**）：

- 像素 8-bit / 16-bit（怀旧街机 / 复古解谜）
- 卡通扁平（休闲 / 家庭娱乐）
- 极简几何（益智解谜 / 抽象类）
- 霓虹未来（赛博跑酷 / 节奏类）
- 手绘水彩 / 涂鸦（绘本 / 儿童 / 剧情）

风格词写进 plan 一行，后续配色、字体、生图、动效都依据这条决策。

### 游戏素材 prompt 公式（本任务特有，与 `references/common/image-generation.md` 通用公式不同）

```
[游戏元素] + [素材类型] + [风格词] + [构图/视角] + [配色] + flat icon, transparent background, game asset, no text overlay
```

游戏要的是 **game sprite / tile / character icon**，构图是"中央元素 + 透明背景"，**不是**电影级场景。

| 部分 | 推导依据 | 示例 |
|---|---|---|
| 游戏元素 | 玩法本身 | "数字方块 2/4/8"、"卡通蛇头"、"打砖块块"、"答题角色头像" |
| 素材类型 | 用途 | "game tile sprite"、"character avatar"、"background tile"、"icon button" |
| 风格词 | 上面已推 | "pixel 16-bit"、"flat cartoon"、"minimalist geometric"、"neon cyber" |
| 构图 | 素材常用中央透明 | "centered icon, transparent background" / "seamless pattern"（背景平铺） |
| 配色 | 跟主题色一致 | "warm earth tones"、"high contrast neon" |

通用尾部固定追加：`flat icon, transparent background, game asset, no text overlay, no UI mockup`。

仅需要场景背景大图（非精灵）时才用 16:9 横构图。

## 6. 难度 / 反馈 / 持久化

### 难度曲线

- **第一局别 3 秒死**：起手难度必须让玩家拿到 ≥ 1 次反馈循环（≥ 1 个合并、≥ 1 次得分、≥ 1 关通过）才"开始有挑战"
- **进度感**至少满足一种：得分递增 / 速度递增 / 关卡推进 / 等级提升 / 棋盘扩大
- 无限模式：动态调难度（每 N 分加速 / 每 N 关增加敌人）。有限关卡：内嵌数据，关卡 ≥ 5

### 反馈强度（HTML 单文件无音频默认 → 视觉是核心）

每次有效操作至少触发一种视觉反馈：

- 数字/分数变化用**动画**（弹出、缩放、上浮消失）而非瞬移
- 关键状态变更（合并 / 命中 / 击破 / 答对）用粒子或闪光，1-2 帧高亮
- 错误反馈用**抖动**（CSS keyframes `translate: ±4px`），不要全屏颜色闪烁
- 屏幕震动只对**游戏容器**做 `transform: translate()` 关键帧，**不要**改 body margin / scroll 位置

`alert()` / `confirm()` / `prompt()` **全程禁用**——破坏沉浸。所有提示用游戏内 UI 面板。

### 持久化

- 最高分 `localStorage.setItem('<game>_best', score)`，开局读出来在 HUD 显示
- 当前局进度不必持久化（关 Tab = 重玩）
- localStorage 读写包 `try/catch`（隐私模式可能抛错）

## 游戏特有反模式

- Game Over 后只能 `location.reload()`，"再来一局"按钮实际是刷新页面
- 用 `alert("得分：" + score)` 报分 / 用 `confirm()` 问"是否再来一局"
- 移动端长按游戏元素弹出系统菜单（缺 `user-select: none` / `touch-action: none`）
- 实时类游戏用 `setInterval(loop, 16)` 当主循环
- emoji（🎮🐍🍎🍪）当游戏精灵 / 角色 / 敌人 / 食物
- 棋盘 / 格子用 `position: absolute` + 像素 left/top，而非 CSS Grid
- 暂停按钮存在但无 handler，或暂停后主循环继续空转
- 单一难度——从开局到第 100 分速度毫无变化
- 移动端用 `keydown` / `keypress` 检测输入（移动端无键盘）
- 生图 prompt 写"epic game hero cinematic scene"——产出电影海报而非可用素材

## Worked Example

> 用户输入："做一个 2048 风格的合并解谜小游戏，要好看。"
>
> **§1 类型识别**：回合驱动 + 离散 4×4 网格 + 滑动手势 → 「回合制 / 离散网格 / 滑动 → 合并解谜类」
>
> **§2 状态机**：menu（开始按钮 + 最高分）→ playing（4×4 网格 + 当前分 + 最高分 HUD）→ over（棋盘满且无可合并触发）→ restart 回 playing。无 paused（回合驱动不需要）。
>
> **§3 渲染层**：离散网格 + 回合驱动 → **DOM 网格**：
>
> - CSS Grid `grid-template-columns: repeat(4, 1fr)`，每数字格是 grid item
> - 合并动画 `transform: scale(1.15) → scale(1)` + `transition: 120ms`
> - 新格出现 `scale(0) → scale(1)` 弹出
> - 不上 Canvas
>
> **§4 双端输入**：
>
> - 桌面：`keydown` 绑 4 方向键 + WASD
> - 移动：游戏容器监听 `touchstart/touchend`，按 dx/dy 判 4 方向 swipe
> - 容器加 `user-select: none; touch-action: none;`
>
> **§5 视觉风格**：「极简几何 + 暖色阶」（解谜类合适极简）
>
> - 主色按配色规则推：H ≈ 30° 暖橙，S 65% L 55%；灰阶从 30° 派生
> - HUD 字体：`font-family: 'Press Start 2P', monospace, sans-serif`
> - **不调 GenerateImage**——2048 没有精灵需求，纯数字 + 色块就够
>
> **§6 难度 / 反馈 / 持久化**：
>
> - 难度：自然进阶（合并越大越难凑）
> - 反馈：合并时格子 `scale` 弹动 + 数字上浮 `+N`；新格 `scale` 弹出；首次 2048 出现时全屏闪光 + 提示面板
> - 持久化：`localStorage` 存 `best`，开局读
>
> **不要照抄此例**——同样需求另一次推可能选「卡通扁平 + 蓝绿主色」或「霓虹暗色 + Canvas 走粒子合并」，都是合理的。按 §1-§6 维度从本任务重新推导。
