---
name: rich-interactive-design
description: Use when generating HTML single-file artifacts for rich 2D/3D interactive experiences—games, real-time simulations, or 3D immersive scenes. 触发词：game, 游戏, 互动玩法, simulation, 模拟, 仿真, 沙盒, 流体, 布料, 粒子, 物理模拟, 元胞自动机, boid, 生态, interactive scene, 3D 场景, 3D 漫游, 沉浸, 虚拟展厅, 产品 3D 展示, Three.js, 虚拟现实, 数字孪生, 富交互.
hook: SessionStart
available-agents:
  - Html
---

# Rich Interactive Design

3 类富交互前端任务的统一入口：**游戏 / 实时模拟 / 3D 沉浸场景**。承载任务分类路由、跨任务设计原则底座，以及到 `references/` 子模块的渐进式披露。

非富交互类的普通 HTML 任务（落地页、仪表盘、管理后台等）**不在本 skill 范围**——按通用前端设计原则执行，不要硬套本 skill 的方法论。

## §1 任务分类

动手前先判断任务类型。每个新任务归到下列一类，对应到任务文件。

| 分类 | 关键特征 | 对应任务文件 |
|---|---|---|
| `game` | 游戏 / 互动玩法（**有胜负 / 挑战 / 玩法循环**） | `references/tasks/game.md` |
| `simulation` | 实时模拟 / 沙盒 / 物理演示（**无胜负，乐趣来自系统行为本身**：流体、布料、粒子、生态、化学、社会行为等） | `references/tasks/simulation.md` |
| `interactive-scene` | 3D / 沉浸式场景（自然景观、产品展示、虚拟漫游、建筑、3D 数据可视化） | `references/tasks/interactive-scene.md` |
| `out-of-scope` | 不属于以上 3 类的 HTML 任务（落地页、仪表盘、报告、PPT、管理后台等） | 退出本 skill，按通用前端设计原则执行 |

## §2 判定优先级

按以下规则自上而下匹配：

1. **玩法机制优先**：涉及胜负 / 挑战 / 玩法循环 → `game`（即使是 3D 游戏也归 game，不归 interactive-scene）
2. **关键词匹配**：
   - "模拟 / 仿真 / 沙盒 / 流体 / 布料 / 粒子 / 物理 / 元胞自动机 / boid / 生态" → `simulation`
   - "3D 场景 / 沉浸 / 漫游 / 展厅 / 产品 3D 展示 / Three.js 场景 / 虚拟现实 / 数字孪生" → `interactive-scene`
3. **系统行为 vs 视觉空间**：核心是"系统怎么演化" → `simulation`；核心是"场景多美 / 怎么探索" → `interactive-scene`
4. **都不匹配** → `out-of-scope`，**退出本 skill**，不要给非富交互任务套用本 skill 的反模式与维度框架

## §3 跨类任务

按主要篇幅/价值选一个主类，主任务 `references/tasks/<task>.md` 必读。次类元素（如游戏里嵌一个 3D 关卡 / 模拟器里嵌挑战目标）在生成对应模块时读对应类任务文件的相关章节。

plan 中说明「主类 X，包含 Y 模块」即可。

示例：

- **3D 山脉场景 + 隐藏地标找寻挑战**：主类 = `interactive-scene`（整体光照、相机、性能按 scene 规范）；次类元素 = 计分 / 通关 / 反馈按 `game` §6 难度反馈持久化章节
- **物理沙盒 + 关卡式挑战目标**（如愤怒的小鸟）：主类 = `simulation`（物理积分、时间步长按 sim 规范）；次类元素 = 关卡 / 计分按 `game` §2 状态机 + §6 难度章节
- **3D 流体效果展示**（咖啡拉花、wet paint）：主类 = `simulation`（流体算法是核心）；次类元素 = 3D 渲染按 `interactive-scene` §4 渲染性能、§5 光照章节

## §4 易混类目判定

- `game` vs `simulation`：**有胜负 / 挑战目标** → `game`；**无胜负，乐趣来自系统行为本身的可观察 / 可调 / 可创作** → `simulation`。Conway / falling sand 这种无胜负沙盒明确归 `simulation`，不归 `game`
- `simulation` vs `interactive-scene`：**系统行为本身是核心**（流体演化 / 粒子相互作用 / 物理模拟）→ `simulation`；**视觉与空间体验是核心、系统简单或仅作氛围**（3D 山脉的昼夜变化属于氛围演化）→ `interactive-scene`
- `interactive-scene` vs `game`（3D 漫游 vs 3D 游戏）：纯探索 / 观赏 / 信息展示 → `interactive-scene`；有目标 / 障碍 / 胜负 → `game`

判断完后，用人话写进 plan 的任务理解部分（不必报内部标签名）。

## §5 设计原则（跨任务底座）

通用、跨富交互分类的视觉与交互设计底线。具体物理参数、相机配置、性能预算等下沉到任务分类文件。

### 5.1 禁用反模式

富交互场景常翻车的"AI 味"模式：

- emoji 充当游戏精灵 / 角色 / 敌人 / 食物（🎮🐍🍎），或当 UI 功能图标
- `alert()` / `confirm()` / `prompt()` 当反馈或弹窗 —— 破坏沉浸，必须用画布内 UI
- 黑底白字 + Times New Roman 默认样式 —— 一眼"未做设计"
- 占位图走 placeholder.com / unsplash 等不稳定外链
- 七彩 / 多主色（一个作品用 > 2 个主色调），缺乏视觉收敛
- 默认 60fps 假设、`setInterval` 当主循环、不处理 `visibilitychange` 暂停
- 不区分桌面 / 移动端输入（PC 只 keydown / 移动端只 click）
- 加载完成无 fade-in 过渡，首帧突现
- 模拟 / 3D 场景里大面积装饰性紫蓝渐变背景（科幻味的廉价 AI 审美）
- Canvas 2D 字符串颜色用 CSS Level 4 空格分隔语法（`hsl(200 90% 65%)` / `hsla(...)`）—— `addColorStop` / `fillStyle` / `strokeStyle` 只解析 Level 3 逗号分隔，空格分隔抛 `could not be parsed as a color`；CSS 上下文（`style.color` / CSS 变量 / Tailwind 配置）两种语法都支持，但写入 Canvas API 字符串参数（含模板字符串拼接）必须用逗号分隔 `hsla(200, 90%, 65%, 0.9)`

### 5.2 默认设计倾向

无明确指令时按以下方向走：

- **配色**：4-6 色 palette 前置定义 + 全程引用常量，禁止散落 magic color；数值场可视化用 viridis / inferno 等色盲友好梯度
- **字号阶梯**：UI 文字（分数、提示、按钮）字号阶梯清晰，避免 h1/h2/h3 大小近似
- **间距**：8px grid，禁混用任意值（如 `p-[13px]`）
- **留白**：UI 元素之间宁多勿少，密集排不出质感
- **克制**：每个视觉装饰要解决具体问题（反馈玩家行为 / 标识系统状态），不为装饰而装饰
- **文案**：UI 文字根据场景写真实文案（"开始游戏"、"再来一局"、"重置场景"），不要 Lorem ipsum / "Sample Text" / "Button 1"

### 5.3 资产策略

- **路径按视觉目标选**（不分主次）：
  - 抽象 / 程式化 / 卡通 → 程序化（SVG / Canvas / Three.js Geometry / Web Audio）
  - 写实复刻"在用户脑子里有视觉标准答案"的真实物体（地球、人体、汽车……）→ CDN 贴图 + PBR + 真实模型（jsDelivr / threejs.org examples）；程序化几何模拟这类物体一定假
  - 原创艺术内容（角色 sprite、风格化场景、封面）→ GenerateImage 兜底；详见各 task 文件
- **图标**：禁止 emoji 充当功能性图标（导航 / 按钮 / 状态指示），用 Lucide 风格 inline SVG
- **`<img>` alt**：每个 `<img>` 的 `alt` 必须有意义（描述图片内容），不要空 alt 或填文件名
- **占位图**：禁用 placeholder.com 等外链占位服务；需要时用纯 CSS 占位框或程序化生成

### 5.4 排版纪律（UI 覆盖层适用）

UI 覆盖层（HUD、菜单、参数面板）翻车的常见点：

- **对齐统一**：HUD 各元素左右内边距走同一基线，避免分数 `px-4`、暂停按钮 `px-2`、生命槽 `px-6` 这种混搭
- **间距分层**：元素内 padding < 元素间 gap < 区块间 section gap，三层至少 1.5-2 倍差异，UI 才不会糊
- **主从对比**：关键信息（当前分数 / 主操作按钮 / 关键提示）必须靠尺寸、字重、颜色任一维度突出

## §6 渐进式披露指令

识别任务类后，按以下顺序加载文档。**必读组合在同一轮 tool call 中并行 Read**，避免串行等待拉长首响。

### 6.1 已加载

本 SKILL.md §1-§5。

### 6.2 必读组合（同一轮 tool call 并行 Read）

每类任务的 `references/tasks/<task>.md` 都是必读首步。下表列出还要与之**并行加载**的 common 模块（"—" 表示无额外 common，但任务文档本身仍必读）：

| 任务 | 并行加载的 common 模块 |
|---|---|
| `game` | `image-generation.md` |
| `simulation` | `color-system.md`（数值场色彩映射 / 科学可视化配色） |
| `interactive-scene` | `color-system.md` + `image-generation.md`（环境/纹理素材按需） |

common 模块路径前缀统一为 `references/common/`。

### 6.3 按需补读（出现非典型决策时再发起 Read）

- 涉及生图 prompt（如 `simulation` 需要科学可视化封面图）→ `references/common/image-generation.md`
- 涉及配色方法论（如 `game` 走色彩心理学）→ `references/common/color-system.md`
