---
name: debug-investigation
description: "Debug investigation methodology for the Reviewer agent. LOAD THIS SKILL (via read_file) when caller prompt contains symptom keywords: 卡死 / 白屏 / 修不好 / 修不掉 / 报错 / 定位 bug / 为什么 X 不工作 / 出 bug / 故障 / 已经修了 N 次 / hang / crash / broken / doesn't work / can't figure out / still broken. For 'user reported symptom, find root cause' tasks. Runs alongside security/performance/correctness review but does not replace them — pattern libraries come from those skills, this skill only owns the investigation flow (Phase 1-3 + 4.5 Architecture Questioning). 触发词：定位 bug, root cause, 症状排查"
available-agents:
  - Reviewer
---

# Iron Law

NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST.

Reviewer 的工具白名单已物理强制此规则：你无 Edit/Write 权限。
但仍需在报告里拒绝输出"修复建议"直到 Phase 1-3 全部完成。

# Phase 1 — Root Cause Investigation (必做)

1. 读 caller prompt 提取症状：What / When / Where / 触发条件
2. 日志证据：ReadLogs browser / server-devserver / client-devserver / server，
   找对应错误栈、请求 / 响应、console error
3. 近期改动：`git log --oneline -20 <suspected_file>`，必要时看 `git show <sha>`
4. 数据流反向追溯（见下方 5 步流程）
5. 跨组件证据：即使没法 runtime 埋点，也要在报告里列清每层"当前行为 vs
   期望行为"，指出断点

## Phase 1 子步骤：5 步反向追溯

1. **Observe the Symptom** — 复述症状（原封不动引用 caller 的话）
2. **Find Immediate Cause** — 定位最直接触发症状的代码（Read + Grep）
3. **Ask: What Called This?** — 向上一层调用链：用 Grep 找调用方
4. **Keep Tracing Up** — 循环 3-5 次，每次问"这个值/状态是从哪里来的"
5. **Find Original Trigger** — 定位值/状态的最初源头，才算 root cause

**NEVER 只看症状出现的代码行。** 必须追溯到源头，哪怕追 5 层。

# Phase 2 — Pattern Analysis

1. 同项目找"能工作"的类似实现做对比
2. 列差异点，不放过任何一点
3. 必要时调用 security-review / performance-review / correctness-review
   skill 作为 pattern 库

# Phase 3 — Hypothesis (证据驱动)

1. 形成假设："症状 X 由 Y 处代码触发，因为 Z"
2. 从代码和日志找反证或佐证，不是"猜"
3. 证据不足时明确标注：
   `Hypothesis: <陈述> · Confidence: Low · Need evidence: <需要什么证据>`

# Phase 4.5 — Architecture Questioning

MUST run `git log --oneline -20 <suspected_file>` before writing report.

触发条件（两步判断，都满足才触发）：

1. **Commit message regex 匹配**：
   `^\w+\s+(fix|hotfix|patch|retry|fallback|workaround|band-?aid|修复|临时|打补丁|再修|又修)[\s:(]`
   （case-insensitive；匹配形如 "fix(scope):"、"hotfix xxx"、"修复 xxx"、"再修 X"）
2. **变更性质判断**：对匹配的 commit 跑 `git show <sha> --stat`，若 ≥3 个 commit
   都满足"同一 / 邻近文件内新增 regex / 新增条件分支 / 新增 catch / 新增
   fallback"而**没有**"函数签名变化 / 模块拆分 / 文件新增或大幅重写" → 判定为
   "叠加式修复"

若两条件都满足 → 必须在报告里输出：

> ⚠️ ARCHITECTURE SMELL: 此文件近 20 个 commit 里有 N 次"叠加式修复"
> （commit: [sha1, sha2, ...]），建议停止继续打补丁，考虑架构重构为 <重构方向>

否则本节省略。

# Red Flags — STOP and Follow Process

If you catch yourself thinking:

- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "Add multiple changes, run tests"
- "It's probably X, let me fix that"
- "I don't fully understand but this might work"
- "Here are the main problems: [lists fixes without investigation]"
- "Proposing solutions before tracing data flow"
- "One more fix attempt" (when already tried 2+)
- "Each fix reveals new problem in different place"

**ALL of these mean: STOP. Return to Phase 1.**

# Common Rationalizations

| Excuse | Reality |
|---|---|
| "Issue is simple, don't need process" | Simple issues have root causes too. Process is fast for simple bugs. |
| "Emergency, no time for process" | Systematic debugging is FASTER than guess-and-check thrashing. |
| "Just try this first, then investigate" | First fix sets the pattern. Do it right from the start. |
| "Multiple fixes at once saves time" | Can't isolate what worked. Causes new bugs. |
| "I see the problem, let me fix it" | Seeing symptoms ≠ understanding root cause. |
| "One more fix attempt" (after 2+ failures) | 3+ failures = architectural problem. Question pattern, don't fix again. |

# Output Format (debug 模式)

```
# Bug Investigation Report

## 症状 (from caller)
<一句话复述用户报告的症状，包括触发条件>

## Phase 1 证据链
按数据流从前向后逐层列证据，每层都给 file:line：

- Layer N · `path/to/file.ts:L1-L2`
  当前行为：<代码实际做什么>
  期望行为：<按业务意图应该做什么>
  **断点**：<具体哪一步出了问题>

（按实际涉及的层数重复，典型为 Frontend → Network → Service → Persistence）

## 根因假设 (Confidence)
- **主假设** · Confidence: High / Medium / Low
  <清晰陈述：症状 X 由 Y 处触发，因为 Z>
- **并发假设**（如有）· Confidence: ...
  <另一个独立成立的根因>
- **次生假设** · Confidence: ...
  <修复主假设后仍可能引发新症状的风险点>

## ⚠️ ARCHITECTURE SMELL (Phase 4.5 触发时才写)
`git log --oneline -20 <file>` 显示近 20 个 commit 里有 N 次叠加式修复。
commits: [sha1, sha2, sha3, ...]

重构方向：
1. <重构方向 1>
2. <重构方向 2>

## 修复方向（不写具体代码）
给 CodeAgent 的 Action Items：
1. [P0] <最关键的根因修复：改哪个文件哪一行 + 改成什么结构>
2. [P0/P1/P2] <次要修复>

## Verdict
<Needs debug + architecture refactor / Needs targeted fix / Needs more evidence>
```

**Rules**:

- 每个 Layer 必须给 `file:line`，不能只说"前端"
- 每个假设必须标 Confidence
- Phase 4.5 未触发时整段省略
- 修复方向**禁止写具体代码**——只给方向，CodeAgent 负责写代码
- 调查未完成前**禁止输出修复方向**段
