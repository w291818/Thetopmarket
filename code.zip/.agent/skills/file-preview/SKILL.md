---
name: file-preview
description: Use when implementing file preview for PDF, Word, Excel, PPT or other office documents. 触发词：文件预览, 预览PDF, 预览Word, pdf preview, docx preview, office preview, 在线预览, file viewer
---

# File Preview

在 Web 应用中实现 PDF 和 Office 文档的在线预览。

## Quick Reference

| 文件类型 | 推荐库 | 包名 |
|----------|--------|------|
| PDF (.pdf) | pdf.js | `pdfjs-dist@^3`（禁止使用 v5） |
| Word (.docx) | docx-preview | `docx-preview` |
| Excel (.xlsx) | SheetJS | `xlsx` |
| PPT (.pptx) | pptx-preview | `pptx-preview` |

## 架构模式：数据获取与渲染分离（必须遵循）

> **CRITICAL:** 所有文件预览组件**必须**拆成两层。混在一起是 ref 为 null、display:none 尺寸为 0、styleContainer 报错等问题的根源。

```
Wrapper（外层）               Renderer（内层）
┌─────────────────────┐      ┌─────────────────────┐
│ - useFileData(url)   │      │ - 只在数据就绪后挂载  │
│ - if loading / error │─────→│ - 容器天然可见        │
│ - 条件渲染 Renderer  │      │ - clientWidth 正确    │
└─────────────────────┘      │ - ref + 预览库渲染    │
                             └─────────────────────┘
```

> **CRITICAL — `url` 必须是文件直链：**
>
> - ✅ 上传文件接口返回的 `download_url`
> - ✅ 三方文件直链（CDN、对象存储等可直接 GET 二进制的 URL）
> - ❌ 后端业务接口 `/api/xxx`：绝大多数场景**不应该**使用这种形式获取文件内容。如果确实只有后端接口可用，必须走项目统一的带鉴权请求封装，不能用裸 `fetch` 直连业务接口。

通用数据获取 hook（所有预览组件共用）：

```tsx
import { useState, useEffect } from 'react';

function useFileData(url: string) {
  const [data, setData] = useState<ArrayBuffer | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError(null);
    fetch(url, { signal: controller.signal })
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.arrayBuffer();
      })
      .then((buf) => setData(buf))
      .catch((err) => {
        if (err.name !== 'AbortError') setError(err.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [url]);

  return { data, loading, error };
}
```

## PDF 预览（pdfjs-dist）——完整参考示例

> **必须使用 v3**（`pdfjs-dist@^3.11.174`）。v5 存在兼容性问题。

```bash
npm install pdfjs-dist@^3.11.174
```

```tsx
import { useEffect, useRef } from 'react';
import * as pdfjsLib from 'pdfjs-dist';

// CRITICAL: 必须配置 workerSrc，否则 PDF 无法渲染或主线程阻塞卡死
// v3 路径为 pdf.worker.min.js（非 .mjs）
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.js',
  import.meta.url
).toString();

// 外层：获取数据，管理 loading/error
export function PdfViewer({ url }: { url: string }) {
  const { data, loading, error } = useFileData(url);
  if (loading) return <div className="text-center p-4">正在加载PDF...</div>;
  if (error) return <div className="text-destructive p-4">{error}</div>;
  return <PdfRenderer data={data!} />;
}

// 内层：只负责渲染，挂载时容器一定可见
function PdfRenderer({ data }: { data: ArrayBuffer }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    let pdfDoc: pdfjsLib.PDFDocumentProxy | null = null;

    const render = async () => {
      pdfDoc = await pdfjsLib.getDocument({ data }).promise;
      const container = containerRef.current;
      if (cancelled || !container) {
        pdfDoc.destroy();
        pdfDoc = null;
        return;
      }
      container.innerHTML = '';

      const containerWidth = container.clientWidth;
      for (let i = 1; i <= pdfDoc.numPages; i++) {
        if (cancelled) break;
        const page = await pdfDoc.getPage(i);
        // 根据容器宽度动态计算缩放比例，实现自适应宽度
        const defaultViewport = page.getViewport({ scale: 1 });
        const scale = containerWidth / defaultViewport.width;
        const viewport = page.getViewport({ scale });
        const canvas = document.createElement('canvas');
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        canvas.style.width = '100%';
        canvas.style.height = 'auto';
        container.appendChild(canvas);
        await page.render({
          canvasContext: canvas.getContext('2d')!,
          viewport,
        }).promise;
      }
    };
    render();

    return () => {
      cancelled = true;
      // 释放 pdfjs 文档资源（内部 worker 通信、页面缓存等）
      if (pdfDoc) {
        pdfDoc.destroy();
        pdfDoc = null;
      }
    };
  }, [data]);

  return <div ref={containerRef} className="flex flex-col items-center gap-4 w-full" />;
}
```

| 注意事项 | 说明 |
|------|------|
| **Worker 必须配置** | 不配置会阻塞主线程或直接报错。v3 路径为 `pdf.worker.min.js`（不是 `.mjs`） |
| 大文件分页加载 | 页数 > 20 时应按需渲染可视区域页面 |
| 缩放比例 | `scale` 建议 1.5-2.0，兼顾清晰度和性能 |

## Word / Excel / PPT 预览

外层 Wrapper 结构与 PDF 完全一致（`useFileData` + 条件渲染 Renderer），以下只列出各 Renderer 内层的**关键差异**：

### Word（docx-preview）

```bash
npm install docx-preview
```

```tsx
import { renderAsync } from 'docx-preview';

function DocxRenderer({ data }: { data: ArrayBuffer }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    containerRef.current.innerHTML = '';
    // CRITICAL: 第三个参数 styleContainer 不能传 undefined/null
    // 否则内部访问 styleContainer.childNodes 时报错
    renderAsync(data, containerRef.current, containerRef.current, {
      className: 'docx-preview',
      inWrapper: true,
      ignoreWidth: false,
      ignoreHeight: false,
    });
  }, [data]);

  return <div ref={containerRef} className="w-full overflow-auto" />;
}
```

### Excel（xlsx）

```bash
npm install xlsx
```

{% raw %}
```tsx
import { useState } from 'react';
import * as XLSX from 'xlsx';

function XlsxRenderer({ data }: { data: ArrayBuffer }) {
  const [activeSheet, setActiveSheet] = useState(0);
  const wb = XLSX.read(data, { type: 'array' });
  const sheetName = wb.SheetNames[activeSheet];
  const html = XLSX.utils.sheet_to_html(wb.Sheets[sheetName]);

  return (
    <div className="flex flex-col w-full min-h-0 h-full">
      {wb.SheetNames.length > 1 && (
        <div className="flex gap-1 border-b mb-2 shrink-0">
          {wb.SheetNames.map((name, i) => (
            <button
              key={name}
              onClick={() => setActiveSheet(i)}
              className={`px-3 py-1.5 text-sm ${
                i === activeSheet
                  ? 'border-b-2 border-primary font-medium'
                  : 'text-muted-foreground'
              }`}
            >
              {name}
            </button>
          ))}
        </div>
      )}
      <div
        className="flex-1 min-h-0 overflow-auto [&_table]:min-w-full [&_table]:w-max [&_table]:border-collapse [&_td]:border [&_td]:border-border [&_td]:px-2 [&_td]:py-1 [&_td]:text-sm [&_td]:whitespace-nowrap [&_th]:border [&_th]:border-border [&_th]:px-2 [&_th]:py-1 [&_th]:text-sm [&_th]:bg-muted [&_th]:font-medium [&_th]:whitespace-nowrap"
        dangerouslySetInnerHTML={{ __html: html }}
      />
    </div>
  );
}
```
{% endraw %}

| 注意事项 | 说明 |
|------|------|
| 使用 `sheet_to_html` | 直接生成 HTML 表格，零额外 UI 依赖，预览场景最轻量 |
| 多 Sheet 切换 | 通过 tab 按钮切换 `activeSheet`，按需渲染当前 sheet |
| 表格样式 | 通过 Tailwind 任意值选择器 `[&_table]` 统一设置边框和间距 |

### PPT（pptx-preview）

```bash
npm install pptx-preview
```

```tsx
import { init } from 'pptx-preview';

function PptxRenderer({ data }: { data: ArrayBuffer }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    container.innerHTML = '';
    // init 读取 clientWidth/clientHeight 确定渲染尺寸
    // 因为遵循双层模式，容器挂载时一定可见，尺寸一定正确
    const previewer = init(container, {
      width: container.offsetWidth,
      height: container.offsetHeight,
    });
    previewer.preview(data);
  }, [data]);

  return <div ref={containerRef} className="w-full h-full min-h-[400px]" />;
}
```

## Common Mistakes

| 错误 | 正确做法 |
|------|----------|
| 在同一组件中混合 fetch 和 DOM 渲染 | **必须拆成两层组件**（见架构模式）。外层管 loading/error，内层只在数据就绪后挂载渲染 |
| 未配置 pdf.js Worker | 必须设置 `GlobalWorkerOptions.workerSrc` |
| 使用 pdfjs-dist v5 | v5 兼容性问题，必须用 v3（`pdfjs-dist@^3.11.174`） |
| `renderAsync` 第三个参数传 `undefined` | `styleContainer` 不能为 `undefined`/`null`，否则内部访问 `null.childNodes` 报错。应传 `bodyContainer` 自身或 `document.head` |
| 容器 `display:none` 时读取尺寸 | `clientWidth`/`clientHeight` 为 0，渲染空白。双层模式从根本上避免；若不得已需隐藏，用 `visibility:hidden` |
| 直接传 URL 给 docx-preview | 需先 fetch 转为 ArrayBuffer |
| 一次性渲染所有 PDF 页面 | 大文件用虚拟滚动，按需渲染 |
| 忽略文件类型判断 | 根据扩展名或 MIME type 选择对应组件 |

